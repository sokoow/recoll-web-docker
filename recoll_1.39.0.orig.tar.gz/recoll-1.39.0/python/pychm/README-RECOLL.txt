= Recoll and PyCHM

Up to 2019, PyCHM (https://github.com/dottedmag/pychm) had no Python3 version. The pull request I
submitted for the port in 2018 was sitting there, and so was the Debian bug.
https://github.com/dottedmag/pychm/pull/5

Which is why Recoll forked and bundled pychm, enhanced for Python3. The source repo wass here:
https://github.com/medoc92/pychm
Oops, lost, and apparently no mirror so this is the only copy...

PyCHM now has Python3 support, maybe we will go back to the official version at some point.
